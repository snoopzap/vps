 const { fetchJson, range, parseMarkdown } = require('./lib/function')
const { Telegraf, Context } = require('telegraf')
const fetch = require('node-fetch')
const help = require('./lib/help')
const tele = require('./lib/tele')
const chalk = require('chalk')
const os = require('os')
const fs = require('fs')
const color = (text, color) => { return !color ? chalk.green(text) : chalk.keyword(color)(text) };
const cheerio = require('cheerio')
const axios = require('axios')
const { apikey, bot_token, owner, ownerLink, version, prefix , botName} = JSON.parse(fs.readFileSync(`./config.json`))
const bc = JSON.parse(fs.readFileSync('./bc.json'));
premium = require("./database/premium.json")

  
let entertainment = {}

if (bot_token == '') {
	return console.log('=== BOT TOKEN CANNOT BE EMPTY ===')
}

const bot = new Telegraf(bot_token)

bot.command('Oi', async (duda) => {
	user = tele.getUser(duda.message.from)
	reply('oie')
	})

bot.on('callback_query', async (duda) => {
	cb_data = duda.callbackQuery.data.split('-')
	user_id = Number(cb_data[1])
	if (duda.callbackQuery.from.id != user_id) return duda.answerCbQuery('Desculpe, você não tem o direito de acessar este botão.', { show_alert: true })
	callback_data = cb_data[0]
	user = tele.getUser(duda.callbackQuery.from)
	const isGroup = duda.chat.type.includes('group')
	const groupName = isGroup ? duda.chat.title : ''
	if (!isGroup) console.log(chalk.whiteBright('├'), chalk.cyanBright('[ AÇÃO ]'), chalk.whiteBright(callback_data), chalk.greenBright('De'), chalk.whiteBright(user.full_name))
	if (isGroup) console.log(chalk.whiteBright('├'), chalk.cyanBright('[ AÇÃO ]'), chalk.whiteBright(callback_data), chalk.greenBright('De'), chalk.whiteBright(user.full_name), chalk.greenBright('No grupo'), chalk.whiteBright(groupName))
	if (callback_data == 'help') return await help[callback_data](duda, user.full_name, user_id)
	await help[callback_data](duda, user_id.toString())
	
})

//BANCO DE DADOS ("FAZER MINHA PRÓPRIA API DE CONSULTA")



const dbcpf = JSON.parse(fs.readFileSync('./database/DB PRÓPRIA/cpf.json'))

const dbrg = JSON.parse(fs.readFileSync('./database/DB PRÓPRIA/rg.json'))

const dbcep = JSON.parse(fs.readFileSync('./database/DB PRÓPRIA/cep.json'))

const dbcnpj = JSON.parse(fs.readFileSync('./database/DB PRÓPRIA/cnpj.json'))

const dbplaca = JSON.parse(fs.readFileSync('./database/DB PRÓPRIA/placa.json'))

const dbnome = JSON.parse(fs.readFileSync('./database/DB PRÓPRIA/nome.json'))

const dbtelefone = JSON.parse(fs.readFileSync('./database/DB PRÓPRIA/telefone.json'))

const dbscore = JSON.parse(fs.readFileSync('./database/DB PRÓPRIA/score.json'))

const dbip = JSON.parse(fs.readFileSync('./database/DB PRÓPRIA/ip.json'))

const dbin = JSON.parse(fs.readFileSync('./database/DB PRÓPRIA/bin.json'))

const dbbeneficios = JSON.parse(fs.readFileSync('./database/DB PRÓPRIA/beneficios.json'))

const dbparentes = JSON.parse(fs.readFileSync('./database/DB PRÓPRIA/parentes.json'))

const dbvizinhos = JSON.parse(fs.readFileSync('./database/DB PRÓPRIA/vizinhos.json'))

const dbcns = JSON.parse(fs.readFileSync('./database/DB PRÓPRIA/cns.json'))


bot.on('message', async (duda) => {
	try {
		const body = duda.message.text || duda.message.caption || ''
		comm = body.trim().split(' ').shift().toLowerCase()
		cmd = false
		if (prefix != '' && body.startsWith(prefix)) {
			cmd = true
			comm = body.slice(1).trim().split(' ').shift().toLowerCase()
		}
		const command = comm
		const id = duda.message.id
		const args = await tele.getArgs(duda)
		const user = tele.getUser(duda.message.from)
        const user_id = duda.message.from.id
        const name = user.full_name;
        const name2 = user.username;
		const reply = async (text) => {
			for (var x of range(0, text.length, 4096)) {
return await duda.replyWithMarkdown(text.substr(x, 4096), { disable_web_page_preview: true })
			}
		}

		if (entertainment[duda.update.message.from.id] && entertainment[duda.update.message.from.id] === duda.update.message.text.toLowerCase()) {
			delete entertainment[duda.update.message.from.id]
			return reply('Sua resposta está correta.')
		}

		const isCmd = cmd
		const isGroup = duda.chat.type.includes('group')
		const groupName = isGroup ? duda.chat.title : ''
        
        //const mek = duda.menssage[0]
        const mek = duda
		const isImage = duda.message.hasOwnProperty('photo')
		const isVideo = duda.message.hasOwnProperty('video')
		const isAudio = duda.message.hasOwnProperty('audio')
		const isSticker = duda.message.hasOwnProperty('sticker')
		const isContact = duda.message.hasOwnProperty('contact')
		const isLocation = duda.message.hasOwnProperty('location')
		const isDocument = duda.message.hasOwnProperty('document')
		const isAnimation = duda.message.hasOwnProperty('animation')
		const isMedia = isImage || isVideo || isAudio || isSticker || isContact || isLocation || isDocument || isAnimation

		const quotedMessage = duda.message.reply_to_message || {}
		const isQuotedImage = quotedMessage.hasOwnProperty('photo')
		const isQuotedVideo = quotedMessage.hasOwnProperty('video')
		const isQuotedAudio = quotedMessage.hasOwnProperty('audio')
		const isQuotedSticker = quotedMessage.hasOwnProperty('sticker')
		const isQuotedContact = quotedMessage.hasOwnProperty('contact')
		const isQuotedLocation = quotedMessage.hasOwnProperty('location')
		const isQuotedDocument = quotedMessage.hasOwnProperty('document')
		const isQuotedAnimation = quotedMessage.hasOwnProperty('animation')
		const isQuoted = duda.message.hasOwnProperty('reply_to_message')

		var typeMessage = body.substr(0, 50).replace(/\n/g, '')
		if (isImage) typeMessage = 'Image'
		else if (isVideo) typeMessage = 'Video'
		else if (isAudio) typeMessage = 'Audio'
		else if (isSticker) typeMessage = 'Sticker'
		else if (isContact) typeMessage = 'Contact'
		else if (isLocation) typeMessage = 'Location'
		else if (isDocument) typeMessage = 'Document'
		else if (isAnimation) typeMessage = 'Animation'

		if (!isGroup && !isCmd) console.log(chalk.whiteBright('├'), chalk.cyanBright('[ PRIVADO ]'), chalk.whiteBright(typeMessage), chalk.greenBright('de'), chalk.whiteBright(user.full_name))
		if (isGroup && !isCmd) console.log(chalk.whiteBright('├'), chalk.cyanBright('[  GRUPO  ]'), chalk.whiteBright(typeMessage), chalk.greenBright('de'), chalk.whiteBright(user.full_name), chalk.greenBright('No grupo'), chalk.whiteBright(groupName))
		if (!isGroup && isCmd) console.log(chalk.whiteBright('├'), chalk.cyanBright('[ COMANDO ]'), chalk.whiteBright(typeMessage), chalk.greenBright('de'), chalk.whiteBright(user.full_name))
		if (isGroup && isCmd) console.log(chalk.whiteBright('├'), chalk.cyanBright('[ COMANDO ]'), chalk.whiteBright(typeMessage), chalk.greenBright('de'), chalk.whiteBright(user.full_name), chalk.greenBright('No grupo'), chalk.whiteBright(groupName))

		var file_id = ''
		if (isQuoted) {
			file_id = isQuotedImage
? duda.message.reply_to_message.photo[duda.message.reply_to_message.photo.length - 1].file_id
: isQuotedVideo
? duda.message.reply_to_message.video.file_id
: isQuotedAudio
? duda.message.reply_to_message.audio.file_id
: isQuotedDocument
? duda.message.reply_to_message.document.file_id
: isQuotedAnimation
? duda.message.reply_to_message.animation.file_id
: ''
		}
		var mediaLink = file_id != '' ? await tele.getLink(file_id) : ''
         const q = args.join(' ')


        dono = ["7596032118"]
        const isDono = dono.includes(user_id.toString())
       
        tess = `${duda.chat.id}`
 
 //database
global.db = JSON.parse(fs.readFileSync('./database/database.json'))
if (global.db) global.db = {
    sticker: {},
    database: {},
    game: {},
    settings: {},
    others: {},
    users: {},
    chats: {},
    ...(global.db || {})
}

//salvar database depois de 1 minuto 
setInterval(() => {
 fs.writeFileSync('./database/database.json', JSON.stringify(global.db, null, 2))
}, 60 * 1000)

//Premium infinito 
global.limitawal = {
    premium: "Infinito",
    free: 80
}

global.prem = require("./premium")
const isPremium = isDono || isDono || prem.checkPremiumUser(tess, premium);
prem.expiredCheck(bot, premium);


    try {
 let isNumber = x => typeof x === 'number' && !isNaN(x)
 let limitUser = isPremium ? global.limitawal.premium : global.limitawal.free
 let user = global.db.users[user_id]
 if (typeof user !== 'object') global.db.users[user_id] = {}
 if (user) {
   if (!isNumber(user.afkTime)) user.afkTime = -1
   if (!('afkReason' in user)) user.afkReason = ''
   if (!isNumber(user.limit)) user.limit = limitUser
 } else global.db.users[user_id] = {
   afkTime: -1,
   afkReason: '',
   limit: limitUser,
 }
 let chats = global.db.chats[tess]
   if (typeof chats !== 'object') global.db.chats[tess] = {}
   if (chats) {
  if (!('mute' in chats)) chats.mute = false
  if (!('chatbot' in chats)) chats.chatbot = false
  if (!('antilink' in chats)) chats.antilink = false
  if (!('antilinkyt' in chats)) chats.antilinkyt = false
  if (!('autoblock' in chats)) chats.autoblock = false
  if (!('isWelcome' in chats)) chats.isWelcome = false
  if (!('antilinkall' in chats)) chats.antilinkall = false
  if (!('antiytchannel' in chats)) chats.antiytchannel = false
  if (!('antitiktok' in chats)) chats.antitiktok = false
  if (!('antitelegram' in chats)) chats.antitelegram = false
  if (!('antiinstagram' in chats)) chats.antiinstagram = false
  if (!('antifb' in chats)) chats.antifb = false
  if (!('antibule' in chats)) chats.antibule = false
  if (!('antiwame' in chats)) chats.antiwame = false
  if (!('wame' in chats)) chats.wame = false
  if (!('antitwitter' in chats)) chats.antitwitter = false
  if (!('antivn' in chats)) chats.antivn = false
  if (!('antiphoto' in chats)) chats.antiphoto = false
  if (!('antisticker' in chats)) chats.antisticker = false
  if (!('antivideo' in chats)) chats.antivideo = false
} else global.db.chats[tess] = {
   mute: false,
   chatbot: false,
   wame: false,
   antilink: false,
   antilinkyt: false,
   isWelcome: false,
   antilinkall: false,
   antiytchannel: false,
   antitiktok: false,
   antitelegram: false,
   antiinstagram: false,
   antifb: false,
   antibule: false,
   antiwame: false,
   antitwitter: false,
   antisticker: false,
   antiphoto: false,
   antivn: false,
   antivideo: false,
 }
 let setting = global.db.settings[isDono]
 if (typeof setting !== 'object') global.db.settings[isDono] = {}
    if (setting) {
if (!isNumber(setting.status)) setting.status = 0
if (!('autobio' in setting)) setting.autobio = true
if (!('templateImage' in setting)) setting.templateImage = false
if (!('templateLocation' in setting)) setting.templateLocation = false
if (!('templateGif' in setting)) setting.templateGif = false
if (!('templateMsg' in setting)) setting.templateMsg = false
if (!('templateList' in setting)) setting.templateList = false
if (!('templateDoc' in setting)) setting.templateDoc = false
    } else global.db.settings[isDono] = {
status: 0,
autobio: true,
templateImage: false,
templateLocation: false,
templateGif: false,
templateMsg: false,
templateList: false,
templateDoc: false,
    }
} catch (err) {
 console.error(err)
}

// resetar limite com uma hora
let cron = require('node-cron')
cron.schedule('00 1 * * *', () => {
let user = Object.keys(global.db.data.users)
let limitUser = isPremium ? global.limitawal.premium : global.limitawal.free
for (let jid of user) global.db.data.users[jid].limit = limitUser
console.log('Limite resetado')
}, {
scheduled: true,
timezone: "America/Sao_Paulo"
})


const buttonApagar = async (texts) => {
duda.reply({
                    text: texts
                },{
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{
                                    text: '[  🗑️  ] Apagar [  🗑️  ]',
                                    callback_data: 'delete-' + user_id
                                },

                            ]
                        ]
                    }
                })


  }

const buttonValidar = async (texts) => {
duda.reply({
                    text: texts
                },{
                    parse_mode: 'MARKDOWN',
                    reply_markup: {
                        inline_keyboard: [
                            [{
                                    text: '[  🌀️  ] Atualizar [  🌀️  ]',
                                    callback_data: 'meupauegrande-' + user_id
                                },

                            ]
                        ]
                    }
                })


  }
		switch (command) {
case'start':
case 'help':
case 'menu':
await help.help(duda, user.full_name, duda.message.from.id.toString())
break

case 'alugar':
await help.alugar(duda, user.full_name, duda.message.from.id.toString())
break

case 'validartel':
if (!isDono) return reply("Esse comando e apenas para dono")
bc.telefone = q
fs.writeFileSync('./bc.json', JSON.stringify(bc, null, '\t'))
buttonValidar("Aperte no botão abaixo para o bot ser atualizado:")
break

case 'validartel2':
if (!isDono) return reply("Esse comando e apenas para dono")
bc.telefone2 = q
fs.writeFileSync('./bc.json', JSON.stringify(bc, null, '\t'))
buttonValidar("Aperte no botão abaixo para o bot ser atualizado:")
break

case 'validartel3':
if (!isDono) return reply("Esse comando e apenas para dono")
bc.telefone3 = q
fs.writeFileSync('./bc.json', JSON.stringify(bc, null, '\t'))
buttonValidar("Aperte no botão abaixo para o bot ser atualizado:")
break

case 'validartel4':
if (!isDono) return reply("Esse comando e apenas para dono")
bc.telefone4 = q
fs.writeFileSync('./bc.json', JSON.stringify(bc, null, '\t'))
buttonValidar("Aperte no botão abaixo para o bot ser atualizado:")
break

case 'validarcpf':
if (!isDono) return reply("Esse comando e apenas para dono")
bc.cpf = q
fs.writeFileSync('./bc.json', JSON.stringify(bc, null, '\t'))
buttonValidar("Aperte no botão abaixo para o bot ser atualizado:")
break

case 'validarcpf2':
if (!isDono) return reply("Esse comando e apenas para dono")
bc.cpf2 = q
fs.writeFileSync('./bc.json', JSON.stringify(bc, null, '\t'))
buttonValidar("Aperte no botão abaixo para o bot ser atualizado:")
break

case 'validarcpf3':
if (!isDono) return reply("Esse comando e apenas para dono")
bc.cpf3 = q
fs.writeFileSync('./bc.json', JSON.stringify(bc, null, '\t'))
buttonValidar("Aperte no botão abaixo para o bot ser atualizado:")
break

case 'validarcpf4':
if (!isDono) return reply("Esse comando e apenas para dono")
bc.cpf4 = q
fs.writeFileSync('./bc.json', JSON.stringify(bc, null, '\t'))
buttonValidar("Aperte no botão abaixo para o bot ser atualizado:")
break

case 'validarcnpj':
if (!isDono) return reply("Esse comando e apenas para dono")
bc.cnpj = q
fs.writeFileSync('./bc.json', JSON.stringify(bc, null, '\t'))
buttonValidar("Aperte no botão abaixo para o bot ser atualizado:")
break

case 'validarcns':
if (!isDono) return reply("Esse comando e apenas para dono")
bc.cns = q
fs.writeFileSync('./bc.json', JSON.stringify(bc, null, '\t'))
buttonValidar("Aperte no botão abaixo para o bot ser atualizado:")
break

case 'validarbin':
if (!isDono) return reply("Esse comando e apenas para dono")
bc.bin = q
fs.writeFileSync('./bc.json', JSON.stringify(bc, null, '\t'))
buttonValidar("Aperte no botão abaixo para o bot ser atualizado:")
break

case 'validarip':
if (!isDono) return reply("Esse comando e apenas para dono")
bc.ip = q
fs.writeFileSync('./bc.json', JSON.stringify(bc, null, '\t'))
buttonValidar("Aperte no botão abaixo para o bot ser atualizado:")
break

case 'validarplaca':
if (!isDono) return reply("Esse comando e apenas para dono")
bc.placa = q
fs.writeFileSync('./bc.json', JSON.stringify(bc, null, '\t'))
buttonValidar("Aperte no botão abaixo para o bot ser atualizado:")
break

case 'validarplaca2':
if (!isDono) return reply("Esse comando e apenas para dono")
bc.placa2 = q
fs.writeFileSync('./bc.json', JSON.stringify(bc, null, '\t'))
buttonValidar("Aperte no botão abaixo para o bot ser atualizado:")
break

case 'validarvizinhos':
if (!isDono) return reply("Esse comando e apenas para dono")
bc.vizinhos = q
fs.writeFileSync('./bc.json', JSON.stringify(bc, null, '\t'))
buttonValidar("Aperte no botão abaixo para o bot ser atualizado:")
break

case 'validarparentes':
if (!isDono) return reply("Esse comando e apenas para dono")
bc.parentes = q
fs.writeFileSync('./bc.json', JSON.stringify(bc, null, '\t'))
buttonValidar("Aperte no botão abaixo para o bot ser atualizado:")
break

case 'validarnome':
if (!isDono) return reply("Esse comando e apenas para dono")
bc.nome = q
fs.writeFileSync('./bc.json', JSON.stringify(bc, null, '\t'))
buttonValidar("Aperte no botão abaixo para o bot ser atualizado:")
break

case 'validarnome2':
if (!isDono) return reply("Esse comando e apenas para dono")
bc.nome2 = q
fs.writeFileSync('./bc.json', JSON.stringify(bc, null, '\t'))
buttonValidar("Aperte no botão abaixo para o bot ser atualizado:")
break

case 'validarcorreio':
if (!isDono) return reply("Esse comando e apenas para dono")
bc.correio = q
fs.writeFileSync('./bc.json', JSON.stringify(bc, null, '\t'))
buttonValidar("Aperte no botão abaixo para o bot ser atualizado:")
break

case 'validarddd':
if (!isDono) return reply("Esse comando e apenas para dono")
bc.ddd = q
fs.writeFileSync('./bc.json', JSON.stringify(bc, null, '\t'))
buttonValidar("Aperte no botão abaixo para o bot ser atualizado:")
break

case 'addpremium':  
if (!isDono) return reply('Só pra gente foda')
if (!q) return reply('Cadê o id do usuário/Grupo')
premium.push(`${q}`)
fs.writeFileSync('./lib/premium.json', JSON.stringify(premium))
reply(`Pronto ${q} você foi adicionado na lista premium.`)
break

case 'addprem':
try {
if (!isDono) return reply('Só pra gente foda')
prem.addPremiumUser(args[0], args[1], premium);
reply('Premium adicionado com sucesso mestre 🔥')
const chatType = duda.chat.type;

  if (chatType === 'private') {
    bot.telegram.sendMessage(args[0], `Olá, seu Premium de ${args[1]}, acabou de ser validado, aproveite o máximo os recursos do bot!\n\nAlém das puxadas, aqui você encontra vantagens que outros bots não tem, como logos, Downloads, Inteligencias artificiais (simi, ChatGPT), brincadeiras, geradores entre outros, tudo em apenas um bot!\n\nConsultas disponíveis abaixo:\n\n🔎 TELEFONE \n🔎 CPF \n🔎 CPF2 \n🔎 PLACA \n🔎 NOME \n🔎 CNPj`);
   } else if (chatType === 'group' || chatType === 'supergroup') {
    bot.telegram.sendMessage(args[0], `Olá participantes do grupo! O premium de ${args[1]} do grupo acabou de ser validado,aproveite o máximo os recursos do bot!\n\nAlém das puxadas, aqui você encontra vantagens que outros bots não tem, como logos, Downloads, Inteligencias artificiais (simi, ChatGPT), brincadeiras, geradores entre outros, tudo em apenas um bot!\n\nConsultas disponíveis abaixo:\n\n🔎 TELEFONE \n🔎 CPF \n🔎 CPF2 \n🔎 PLACA \n🔎 NOME \n🔎 CNPj`);
  } else {
        bot.telegram.sendMessage(args[0], `Olá, seu premium/desse grupo de ${args[1]} acabou de ser validado, aproveite o máximo os recursos do bot!\n\nAlém das puxadas, aqui você encontra vantagens que outros bots não tem, como logos, Downloads, Inteligencias artificiais (simi, ChatGPT), brincadeiras, geradores entre outros, tudo em apenas um bot!\n\nConsultas disponíveis abaixo:\n\n🔎 TELEFONE 1\n🔎 TELEFONE 2\n🔎 TELEFONE \n🔎 CPF \n🔎 CPF2 \n🔎 PLACA \n🔎 NOME \n🔎 CNPj`);
  }
  } catch(e){
  console.log(e)
  }
break

case 'id':
reply(`${duda.chat.id}`)
break

case 'gerarcpf':
if (!isPremium) return reply('Comando só pode ser usado por usuário Premiums')
cp1 = `${Math.floor(Math.random() * 300) + 600}`
cp2 = `${Math.floor(Math.random() * 300) + 600}`
cp3 = `${Math.floor(Math.random() * 300) + 600}`
cp4 = `${Math.floor(Math.random() * 30) + 60}`
cpf = `${cp1}.${cp2}.${cp3}-${cp4}`
reply( `CPF gerado com sucesso!!⚡:\n\n ${cpf}`)
break

case 'eval':
if(!isDono) return reply('So meu dono')
try {
eval(q)
} catch (err) {
reply(`${err}`)
}
break

case 'covid':
case 'covidbr':
if (!isPremium) return reply('Você não é vip, por gentileza, fale com o meu dono!: @necrofalante') 	
if (!q) return reply(`Insira o código\n\nExemple: ${prefix}covid Rj`)
qq = qq = q.normalize('NFD').replace(/[\u0300-\u036f]/g, "").toLowerCase().trim()
bct = await axios.get(`https://covid19-brazil-api.now.sh/api/report/v1/brazil/uf/${qq}`, {method: 'get'}).catch(err => {
  reply(`Talvez a api tenha caido! Tente novamente mais tarde!`)
})
if(bct?.error){
  reply(`Codigo Invalido!\n\nExemplo de uso: ${prefix}covid Rj`)
}
if(bct.state == undefined) return reply(`Erro! Tente digitar um estado válido com o codigo UF\n\nExemplo: ${prefix}covid Rj`)
Lizinho = `✅Selecionado: ${bct.state}\n\n🗣️Pedido: ${bct.uf}\n\n🦠Infectados: ${bct.cases.toLocaleString('pt-BR')}\n\n☠️Mortes: ${bct.deaths.toLocaleString('pt-BR')}\n\n👥Não confirmado: ${bct.suspects.toLocaleString('pt-BR')}\n\n📅Data de atualização: ${bct.datetime}️️`     
reply(Lizinho)
break

case 'beneficios':
case 'beneficio':
try {
 if (!isPremium) return reply('Você não é vip, por gentileza, fale com o meu dono!: @necrofalante') 
if (q.length < 3) return  reply(`Exemple: /beneficio NumeroDoCpfOuCnpj`)
 reply(`Aguarde *${name},* estou a procurar os dados do alvo em meu BANCO DE DADOS...`)
 console.log(`${color(`• [CONSULTA] ~>`, 'yellow')} ${color('Consultando o Score', 'pink')} ${color(`${q}`, 'white')}`)
alizin = await fetchJson(`http://fra2.to.esthosting.com.br:30003/beneficios/${q}`);
reply(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝘽𝙀𝙉𝙀𝙁𝙄𝘾𝙄𝙊𝙎 🕵️
═════════════════

${alizin.resultado.str}


*DONO: [@necrofalante]*
═════════════════`)
dbbeneficios.push(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝘽𝙀𝙉𝙀𝙁𝙄𝘾𝙄𝙊𝙎 🕵️
═════════════════

${alizin.resultado.str}


*DONO: [@necrofalante]*
═════════════════`)
fs.writeFileSync('./database/DB PRÓPRIA/beneficios.json',JSON.stringify(dbbeneficios, null, 1))
} catch (e) {
reply(`Ola *${name},* Ocorreu Um Erro Nas Minhas Buscas, Reporte Ao Meu PROGRAMADOR.`)
}
break


case 'rg':
case 'rg1':
case 'rg2':
try {
 if (!isPremium) return reply('Você não é vip, por gentileza, fale com o meu dono!: @necrofalante') 
if (q.length < 3) return  reply(`Exemple: /Rg NumeroDoRg`)
 reply(`Aguarde *${name},* estou a procurar os dados do alvo em meu BANCO DE DADOS...`)
 console.log(`${color(`• [CONSULTA] ~>`, 'yellow')} ${color('Consultando o Score', 'pink')} ${color(`${q}`, 'white')}`)
alizin = await fetchJson(`http://fra2.to.esthosting.com.br:30003/rg/${q}`);
reply(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 RG 🕵️
═════════════════

${alizin.resultado.str}


*DONO: [@necrofalante]*
═════════════════`)
dbbeneficios.push(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 RG 🕵️
═════════════════

${alizin.resultado.str}


*DONO: [@necrofalante]*
═════════════════`)
fs.writeFileSync('./database/DB PRÓPRIA/rg.json',JSON.stringify(dbrg, null, 1))
} catch (e) {
reply(`Ola *${name},* Ocorreu Um Erro Nas Minhas Buscas, Reporte Ao Meu PROGRAMADOR.`)
}
break


case 'bin':
case 'bim':
if (!isPremium) return reply('Você não é vip, por gentileza, fale com o meu dono!: @necrofalante') 	
if (!q) return reply(`Use assim: /bin 45717360 ( tem 8 digitos! )`)
try {
reply(`*CONSULTANDO BIN: ${q} 🔍*`)
AlizinPush = await fetchJson(`https://lookup.binlist.net/${q}`)
reply(`
❱ LENGTH: ${AlizinPush.number.length}
❱ LUHN: ${AlizinPush.number.luhn}\n\n
*INFOS CARD 💳*
❱ BANDEIRA: ${AlizinPush["scheme"]}
❱ TIPO: ${AlizinPush["type"]}
❱ BRAND: ${AlizinPush["brand"]}
❱ PREPAID: ${AlizinPush["prepaid"]}\n\n
*INFOS BANK 🏦*
❱ BANK NAME: ${AlizinPush.bank["name"]}
❱ BANK URL: ${AlizinPush.bank["url"]}
❱ BANK PHONE: ${AlizinPush.bank["phone"]}
❱ BANK CITY: ${AlizinPush.bank["city"]}\n\n
*INFOS LOC 📍*
❱ NUMERIC: ${AlizinPush.country["numeric"]}
❱ ALPHA2: ${AlizinPush.country["alpha2"]}
❱ NAME: ${AlizinPush.country["name"]}
❱ CURRENCY: ${AlizinPush.country["currency"]}
❱ LATITUDE: ${AlizinPush.country["latitude"]}
❱ LONGITUDE: ${AlizinPush.country["longitude"]}`)
} catch {
return reply(`*Bin invalida*`)
}
break



case 'vizinhos':
case 'vizinho':		
 if (!isPremium) return reply('Você não é vip, por gentileza, fale com o meu dono!: @necrofalante') 
try {
if (q.length < 3) return  reply(`Exemple: /score NumeroDoCpfOuCnpj`)
 reply(`Aguarde *${name},* estou a procurar os dados do alvo em meu BANCO DE DADOS...`)
 console.log(`${color(`• [CONSULTA] ~>`, 'yellow')} ${color('Consultando o Score', 'pink')} ${color(`${q}`, 'white')}`)
alizin = await fetchJson(`http://fra2.to.esthosting.com.br:30003/vizinhos/${q}`);
reply(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝙋𝘼𝙍𝙀𝙉𝙏𝙀𝙎 🕵️
═════════════════

${alizin.resultado.str}

*DONO: [@necrofalante]*
═════════════════`)
dbvizinhos.push(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝙋𝘼𝙍𝙀𝙉𝙏𝙀𝙎 🕵️
═════════════════

${alizin.resultado.str}

*DONO: [@necrofalante]*
═════════════════`)
fs.writeFileSync('./database/DB PRÓPRIA/vizinhos.json',JSON.stringify(dbvizinhos, null, 1))
} catch (e) {
reply(`Ola *${name},* Ocorreu Um Erro Nas Minhas Buscas, Reporte Ao Meu PROGRAMADOR.`)
}
break


case 'parentes':
case 'parente':	
 if (!isPremium) return reply('Você não é vip, por gentileza, fale com o meu dono!: @necrofalante') 	
try {
if (q.length < 3) return  reply(`Exemple: /score NumeroDoCpf`)
 reply(`Aguarde *${name},* estou a procurar os dados do alvo em meu BANCO DE DADOS...`)
 console.log(`${color(`• [CONSULTA] ~>`, 'yellow')} ${color('Consultando o Score', 'pink')} ${color(`${q}`, 'white')}`)
alizin = await fetchJson(`http://fra2.to.esthosting.com.br:30003/parentes/${q}`);
reply(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝙋𝘼𝙍𝙀𝙉𝙏𝙀𝙎 🕵️
═════════════════

${alizin.resultado.str}
*DONO: [@necrofalante]*
═════════════════`)
dbparentes.push(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝙋𝘼𝙍𝙀𝙉𝙏𝙀𝙎 🕵️
═════════════════

${alizin.resultado.str}
*DONO: [@necrofalante]*
═════════════════`)
fs.writeFileSync('./database/DB PRÓPRIA/parentes.json',JSON.stringify(dbparentes, null, 1))
} catch (e) {
reply(`Ola *${name},* Ocorreu Um Erro Nas Minhas Buscas, Reporte Ao Meu PROGRAMADOR.`)
}
break


/*case 'bin':
 /*if (!isPremium) return reply('Você não é vip')      
try {
if (q.length < 3) return  reply(`Exemple: /bin numeroDoBin`)
 reply(`Aguarde *${name},* estou a procurar os dados do alvo em meu BANCO DE DADOS...`)
 console.log(`${color(`• [CONSULTA] ~>`, 'yellow')} ${color('Consultando o Score', 'pink')} ${color(`${q}`, 'white')}`)
binn = await axios.get(`http://8.222.207.34:8080/sky1/bin/${q}`)
reply(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝘽𝙄𝙉 🕵️
═════════════════

${binn.data}
*DONO: [@necrofalante]*
═════════════════`)
dbin.push(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝘽𝙄𝙉 🕵️
═════════════════

${binn.data}
*DONO: [@necrofalante]*
═════════════════`)
fs.writeFileSync('./database/DB PRÓPRIA/bin.json',JSON.stringify(dbin, null, 1))
} catch (e) {
reply(`Ola *${name},* Ocorreu Um Erro Nas Minhas Buscas, Reporte Ao Meu PROGRAMADOR.`)
}
break
*/

case 'addpremium':  
if (!q) return reply('Cadê o id do usuário/Grupo')
prekghiggigogmium.push(`${q}`)
fs.writeFileSync('./funções/premium.json', JSON.stringify(prekghiggigogmium))
reply(`Pronto ${q} você foi adicionado na lista premium.`)
break

case 'addprem':
try {
prem.addPremiumUser(args[0], args[1], premium);
reply('Premium adicionado com sucesso mestre 🔥')
const chatType = duda.chat.type;

  if (chatType === 'private') {
    bot.telegram.sendMessage(args[0], `Olá, seu Premium de ${args[1]}, acabou de ser validado, aproveite o máximo os recursos do bot!\n\nAlém das puxadas, aqui você encontra vantagens que outros bots não tem, como logos, Downloads, Inteligencias artificiais (simi, ChatGPT), brincadeiras, geradores entre outros, tudo em apenas um bot!\n\nConsultas disponíveis abaixo:\n\n🔎 TELEFONE \n🔎 CPF \n🔎 CPF2 \n🔎 PLACA \n🔎 NOME \n🔎 CNPJ`);
   } else if (chatType === 'group' || chatType === 'supergroup') {J
    bot.telegram.sendMessage(args[0], `Olá participantes do grupo! O premium de ${args[1]} do grupo acabou de ser validado,aproveite o máximo os recursos do bot!\n\nAlém das puxadas, aqui você encontra vantagens que outros bots não tem, como logos, Downloads, Inteligencias artificiais (simi, ChatGPT), brincadeiras, geradores entre outros, tudo em apenas um bot!\n\nConsultas disponíveis abaixo:\n\n🔎 TELEFONE \n🔎 CPF \n🔎 CPF2 \n🔎 PLACA \n🔎 NOME \n🔎 CNPJ`);
  } else {
bot.telegram.sendMessage(args[0], `Olá, seu premium/desse grupo de ${args[1]} acabou de ser validado, aproveite o máximo os recursos do bot!\n\nAlém das puxadas, aqui você encontra vantagens que outros bots não tem, como logos, Downloads, Inteligencias artificiais (simi, ChatGPT), brincadeiras, geradores entre outros, tudo em apenas um bot!\n\nConsultas disponíveis abaixo:\n\n🔎 TELEFONE \n🔎 CPF \n🔎 CPF2 \n🔎 PLACA \n🔎 NOME \n🔎 CNPJ`);
  }
  } catch (e) {
console.log(e)
}
break


case 'cns':
if (!isPremium) return reply('Você não é vip, por gentileza, fale com o meu dono!: @necrofalante') 	
try {
if (q.length < 3) return  reply(`Exemple: /cns numeroDoCns`)
 reply(`Aguarde *${name},* estou a procurar os dados do alvo em meu BANCO DE DADOS...`)
 console.log(`${color(`• [CONSULTA] ~>`, 'yellow')} ${color('Consultando o cns', 'pink')} ${color(`${q}`, 'white')}`)
binn = await axios.get(`http://8.222.207.34:8080/sky1/cns/${q}`)
reply(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝘽𝙄𝙉 🕵️
═════════════════

${binn.data}
*DONO: [@necrofalante]*
═════════════════`)
dbin.push(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 CNS 🕵️
═════════════════

${binn.data}
*DONO: [@necrofalante]*
═════════════════`)
fs.writeFileSync('./database/DB PRÓPRIA/cns.json',JSON.stringify(dbcns, null, 1))
} catch (e) {
reply(`Ola *${name},* Ocorreu Um Erro Nas Minhas Buscas, Reporte Ao Meu PROGRAMADOR.`)
}
break

case 'score':
if (!isPremium) return reply('Você não é vip, por gentileza, fale com o meu dono!: @necrofalante') 
try {
if (q.length < 3) return  reply(`Exemple: /score NumerodocpfOuCnpj`)
 reply(`Aguarde *${name},* estou a procurar os dados do alvo em meu BANCO DE DADOS...`)
 console.log(`${color(`• [CONSULTA] ~>`, 'yellow')} ${color('Consultando o Score', 'pink')} ${color(`${q}`, 'white')}`)
alizin = await fetchJson(`http://fra2.to.esthosting.com.br:30003/score/${q}`);
reply(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝙎𝘾𝙊𝙍𝙀 🕵️
═════════════════

${alizin.resultado.str}
*DONO: [@necrofalante]*
═════════════════`)
dbscore.push(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝙎𝘾𝙊𝙍𝙀 🕵️
═════════════════

${alizin.resultado.str}
*DONO: [@necrofalante]*
═════════════════`)
fs.writeFileSync('./database/DB PRÓPRIA/score.json',JSON.stringify(dbscore, null, 1))
} catch (e) {
reply(`Ola *${name},* Ocorreu Um Erro Nas Minhas Buscas, Reporte Ao Meu PROGRAMADOR.`)
}
break


case 'cep': 
if (!isPremium) return reply('Você não é vip, por gentileza, fale com o meu dono!: @necrofalante') 
{  
if(!texto) return reply(`🔍 CONSULTA FREE 🔍
━━━━━━━━━━━━━━━━
╭──────────────
┇   𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗖𝗘𝗣:  
╰──────────────

Você precisa digitar o comando e em seguida, digite o cep da rua/bairro que deseja consultar.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
/cep 70040010
━━━━━━━━━━━━━━━━`)
reply(`Aguarde *${name},* estou a procurar os dados do alvo em meu BANCO DE DADOS...`)
try {
var query = texto
.split('.').join('')
.split('-').join('')
.split('/').join('')
.split(' ').join('');   
let apiAlizin = await axios.get(`https://viacep.com.br/ws/${q}/json/`) 
console.log(`${color(`• [CONSULTA] ~>`, 'yellow')} ${color('Consultando o cep', 'pink')} ${color(`${text}`, 'white')}`)
if (apiAlizin != undefined && apiAlizin != "Não encontrado" && apiAlizin != "Inválido") {
reply(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗖𝗘𝗣 🕵️
═════════════════

*CEP :* ${apiAlizin.cep}\n
*RUA :* ${apiAlizin.logradouro}\n
*COMPLEMENTO :* ${apiAlizin.complemento}\n
*BAIRRO :* ${apiAlizin.bairro}\n
*LOCALIDADE :* ${apiAlizin.localidade}\n
*UF :* ${apiAlizin.uf}\n
*IBGE :* ${apiAlizin.ibge}\n
*GIA :* ${apiAlizin.gia}\n\n
*DDD :* ${apiAlizin.ddd}\n
*SIAFI :* ${apiAlizin.siafi}\n


*DONO: [@necrofalante]*
═════════════════`)
dbcep.push(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗖𝗘𝗣 🕵️
═════════════════

*CEP :* ${apiAlizin.cep}\n
*RUA :* ${apiAlizin.logradouro}\n
*COMPLEMENTO :* ${apiAlizin.complemento}\n
*BAIRRO :* ${apiAlizin.bairro}\n
*LOCALIDADE :* ${apiAlizin.localidade}\n
*UF :* ${apiAlizin.uf}\n
*IBGE :* ${apiAlizin.ibge}\n
*GIA :* ${apiAlizin.gia}\n\n
*DDD :* ${apiAlizin.ddd}\n
*SIAFI :* ${apiAlizin.siafi}\n


*DONO: [@necrofalante]*
═════════════════`)
fs.writeFileSync('./database/DB PRÓPRIA/cep.json',JSON.stringify(dbcep, null, 1))
} else {
reply(`*⚠️ 𝐂𝜮𝐏 𝐍𝜟̃𝐎 𝜮𝐍𝐂𝐎𝐍𝐓𝐑𝜟𝐃𝐎❗*`) 
}  
} catch(e) {
console.log(e)
reply(`*⚠️ 𝐂𝜮𝐏 𝐍𝜟̃𝐎 𝜮𝐍𝐂𝐎𝐍𝐓𝐑𝜟𝐃𝐎❗*`) 
}
}    
break
    

    
    
case 'cnpj':
 if (!isPremium) return reply('Você não é vip')
if(!q) return reply(`🔍 CONSULTA VIP 🔍
━━━━━━━━━━━━━━━━
╭──────────────
┇   𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗖𝗡𝗣𝗝:  
╰──────────────

Você precisa digitar o comando e em seguida, digite o cnpj da empresa que deseja consultar.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
/cnpj 39708509000129
━━━━━━━━━━━━━━━━`)
reply(`Aguarde  estou a procurar os dados do alvo em meu banco de dados...`)
    var query = q
    .split('.').join('')
    .split('-').join('')
    .split('/').join('')
    .split(' ').join('');   
    res = await fetchJson(`https://www.receitaws.com.br/v1/cnpj/${query}`)
    if (query.length < 14 || query.length > 18) return reply(`*⚠️ 𝐅𝐎𝐑𝐌𝜟𝐓𝐎 𝐈𝐍𝐂𝐎𝐑𝐑𝜮𝐓𝐎 ⚠️*
━━━━━━━━━━━━━━━━

O cnpj que você digitou não tem 14 dígitos!

❌ Formato incorreto:

39.708.509/0001-29

✅ Formato correto:

39708509000129

• Use o comando novamente com o cnpj no formato correto.

𝗘𝘅𝗲𝗺𝗽𝗹𝗼:
/cnpj 39708509000129
━━━━━━━━━━━━━━━━`) 
    console.log(`${color(`• [CONSULTA] ~>`, 'yellow')} ${color('Consultando o cnpj', 'pink')} ${color(`${q}`, 'white')}`)
if (res.cnpj != undefined)
try {
let atvpr = `═════════════════\n🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗖𝗡𝗣𝗝 (2) 🕵️\n═════════════════\n\n✍ CNPJ: ${res.cnpj != null ? res.cnpj : "SEM INFORMAÇÕES"}\n\n📝 ATIVIDADE PRINCIPAL:\n`
for(let i of res.atividade_principal) {
    atvpr += `\n- TIPO: ${i.text ? i.text : "SEM INFORMAÇÕES"}`
    atvpr += `\n- CODIGO: ${i.code ? i.code : "SEM INFORMAÇÕES"}\n`
}
consultac = `\n📞 DADOS INFORMATIVOS:\n\nDATA: ${res.data_situacao != null ? res.data_situacao : "SEM INFORMAÇÕES"}`
consultac += `\nCOMPLEMENTO: ${res.complemento != null ? res.complemento : "SEM INFORMAÇÕES"}`
consultac += `\nTIPO: ${res.tipo != null ? res.tipo : "SEM INFORMAÇÕES"}` 
consultac += `\nNOME: ${res.nome != null ? res.nome : "SEM INFORMAÇÕES"}`
consultac += `\nUF: ${res.uf != null ? res.uf : "SEM INFORMAÇÕES"}`
consultac += `\nTELEFONE: ${res.telefone != null ? res.telefone : "SEM INFORMAÇÕES"}`
consultac += `\nEMAIL: ${res.email != null ? res.email : "SEM INFORMAÇÕES"}\n`

teks = `\n👥 ATIVIDADES SECUDARIAS:\n\n`
for(let i of res.atividades_secundarias) {
    teks += `- TIPO: ${i.text ? i.text : "SEM INFORMAÇÕES"}`
    teks += `\n- CODIGO: ${i.code ? i.code : "SEM INFORMAÇÕES"}\n`
}
let qsa = `\n👑 SÓCIOS ADMINISTRATIVOS:\n\n`
for(let i of res.qsa) {
    qsa += `\n- QUAL: ${i.qual ? i.qual : "SEM INFORMAÇÕES"}`
    qsa += `\n- NOME: ${i.nome ? i.nome : "SEM INFORMAÇÕES"}`
    qsa += `\n- REPRESENTANTE LEGAL: ${i.qual_rep_legal ? i.qual_rep_legal : "SEM INFORMAÇÕES"}`
    qsa += `\n- NOME REP. LEGAL: ${i.nome_rep_legal ? i.nome_rep_legal : "SEM INFORMAÇÕES"}\n`
}   
consulta2k = `\n🏬 DADOS & LOCALIZAÇÃO\n\nSITUAÇÃO: ${res.situacao != null ? res.situacao : "SEM INFORMAÇÕES"}`
consulta2k += `\nBAIRRO: ${res.bairro != null ? res.bairro : "SEM INFORMAÇÕES"}`
consulta2k += `\nLOGRADOURO: ${res.logradouro != null ? res.logradouro : "SEM INFORMAÇÕES"}`
consulta2k += `\nNÚMERO: ${res.numero != null ? res.numero : "SEM INFORMAÇÕES"}`
consulta2k += `\nCEP: ${res.cep != null ? res.cep : "SEM INFORMAÇÕES"}`
consulta2k += `\nMUNICIPIO: ${res.municipio != null ? res.municipio : "SEM INFORMAÇÕES"}`
consulta2k += `\nABERTURA: ${res.abertura != null ? res.abertura : "SEM INFORMAÇÕES"}`
consulta2k += `\nNATUREZA JURIDICA: ${res.natureza_juridica != null ? res.natureza_juridica : "SEM INFORMAÇÕES"}`
consulta2k += `\nULTIMA ATUALIZAÇÃO: ${res.ultima_atualizacao != null ? res.ultima_atualizacao : "SEM INFORMAÇÕES"}`
consulta2k += `\nSTATUS: ${res.status != null ? res.status : "SEM INFORMAÇÕES"}`
consulta2k += `\nFANTASIA: ${res.fantasia != null ? res.fantasia : "SEM INFORMAÇÕES"}`
consulta2k += `\nEFR: ${res.efr != null ? res.efr : "SEM INFORMAÇÕES"}`
consulta2k += `\nSITUAÇÃO: ${res.motivo_situacao != null ? res.motivo_situacao : "SEM INFORMAÇÕES"}`
consulta2k += `\nSITUAÇÃO ESPECIAL: ${res.situacao_especial != null ? res.situacao_especial : "SEM INFORMAÇÕES"}`
consulta2k += `\nDATA DA SITUAÇÃO ESPECIAL: ${res.data_situacao_especial != null ? res.data_situacao_especial : "SEM INFORMAÇÕES"}`
consulta2k += `\nCAPITAL SOCIAL: ${res.capital_social != null ? res.capital_social : "SEM INFORMAÇÕES"}`
consulta2k += `\n━━━━━━━━━━━━━━━━`
reply(`${atvpr + consultac + teks + qsa + consulta2k}`)
} catch(e) {
console.log(e)
}
    break
//case de puxar telefone
case 'telefone1': case 'tel1':
case 'tel': case 'telefone':
if (!isPremium) return reply('Você não é vip, por gentileza, fale com o meu dono!: @necrofalante');
try {
    if (q.length < 3) 
        return reply(`⚠️ Exemplo: /telefone NumeroDoAlvo`);

    reply(`Aguarde *${name},* estou a procurar os dados do alvo em meu BANCO DE DADOS...`);
    console.log(`${color('• [CONSULTA] ~>', 'yellow')} ${color('Consultando o Telefone', 'pink')} ${color(`${q}`, 'white')}`);

    const response = await axios.get(`http://br1.sixhosting.online:10000/api/consulta?token=alucard2025&type=telefoneData&query=${q}`);
    const data = response.data;

    if (data && data.itens && data.itens.length > 0) {
        const item = data.itens[0];
        const endereco = item.endereco || {}; // Garantir que `endereco` seja um objeto

        const resultado = `📞 **Consulta de Telefone**\n\n` +
            `👤 **Nome:** ${item.nome || '📵 TELEFONE NÃO ENCONTRADO'}\n` +
            `🧾 **CPF:** ${item.cpf || '📵 TELEFONE NÃO ENCONTRADO'}\n` +
            `🆔 **RG:** ${item.rg || '📵 TELEFONE NÃO ENCONTRADO'}\n` +
            `🎂 **Data de Nascimento:** ${item.nascimento || '📵 TELEFONE NÃO ENCONTRADO'}\n` +
            `👩‍👦 **Nome da Mãe:** ${item.mae || '📵 TELEFONE NÃO ENCONTRADO'}\n` +
            `🏠 **Endereço:**\n` +
            `   • Tipo Logradouro: ${endereco.tipo_logradouro || '📵 TELEFONE NÃO ENCONTRADO'}\n` +
            `   • Logradouro: ${endereco.logradouro || '📵 TELEFONE NÃO ENCONTRADO'}\n` +
            `   • Número: ${endereco.numero || '📵 TELEFONE NÃO ENCONTRADO'}\n` +
            `   • Complemento: ${endereco.complemento || '📵 TELEFONE NÃO ENCONTRADO'}\n` +
            `   • Bairro: ${endereco.bairro || '📵 TELEFONE NÃO ENCONTRADO'}\n` +
            `   • Cidade: ${endereco.cidade || '📵 TELEFONE NÃO ENCONTRADO'}\n` +
            `   • UF: ${endereco.uf || '📵 TELEFONE NÃO ENCONTRADO'}\n` +
            `   • CEP: ${endereco.cep || '📵 TELEFONE NÃO ENCONTRADO'}\n\n` +
            `**Dono:** @necrofalante`;

        reply(resultado);
        dbtelefone.push(resultado);
        fs.writeFileSync('./database/DB PRÓPRIA/telefone.json', JSON.stringify(dbtelefone, null, 1));
    } else {
        reply("⚠️ Nenhuma informação encontrada para o telefone informado.");
    }
} catch (e) {
    reply(`❌ Ocorreu um erro nas minhas buscas. Por favor, reporte ao meu PROGRAMADOR.`);
    console.error('Erro ao realizar consulta de telefone:', e.message);
}
break;




//case de puxar telefone
case 'telefone2': case 'tel2':
if (!isPremium) return reply('Você não é vip, por gentileza, fale com o meu dono!: @necrofalante') 
try {
if (q.length < 3) return  reply(`Exemple: /telefone NumeroDoAlvo`)
 reply(`Aguarde *${name},* estou a procurar os dados do alvo em meu BANCO DE DADOS...`)
 console.log(`${color(`• [CONSULTA] ~>`, 'yellow')} ${color('Consultando o Telefone', 'pink')} ${color(`${q}`, 'white')}`)
alizin = await fetchJson(`http://fra2.to.esthosting.com.br:30003/tel2/${q}`);
reply(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗧𝗘𝗙𝗘𝗙𝗢𝗡𝗘 🕵️
═════════════════

${alizin.resultado.str}


*DONO: [@necrofalante]*
═════════════════`)
dbtelefone.push(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗧𝗘𝗙𝗘𝗙𝗢𝗡𝗘 🕵️
═════════════════

${alizin.resultado.str}


*DONO: [@necrofalante]*
═════════════════`)
fs.writeFileSync('./database/DB PRÓPRIA/telefone.json',JSON.stringify(dbtelefone, null, 1))
} catch (e) {
reply(`Ola *${name},* Ocorreu Um Erro Nas Minhas Buscas, Reporte Ao Meu PROGRAMADOR.`)
}
break

//case de puxar telefone
case 'telefone3': case 'tel3':
if (!isPremium) return reply('Você não é vip, por gentileza, fale com o meu dono!: @necrofalante') 
try {
if (q.length < 3) return  reply(`Exemple: /telefone NumeroDoAlvo`)
 reply(`Aguarde *${name},* estou a procurar os dados do alvo em meu BANCO DE DADOS...`)
 console.log(`${color(`• [CONSULTA] ~>`, 'yellow')} ${color('Consultando o Telefone', 'pink')} ${color(`${q}`, 'white')}`)
alizin = await fetchJson(`http://fra2.to.esthosting.com.br:30003/tel3/${q}`);
reply(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗧𝗘𝗙𝗘𝗙𝗢𝗡𝗘 🕵️
═════════════════

${alizin.resultado.str}


*DONO: [@necrofalante]*
═════════════════`)
dbtelefone.push(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗧𝗘𝗙𝗘𝗙𝗢𝗡𝗘 🕵️
═════════════════

${alizin.resultado.str}


*DONO: [@necrofalante]*
═════════════════`)
fs.writeFileSync('./database/DB PRÓPRIA/telefone.json',JSON.stringify(dbtelefone, null, 1))
} catch (e) {
reply(`Ola *${name},* Ocorreu Um Erro Nas Minhas Buscas, Reporte Ao Meu PROGRAMADOR.`)
}
break

//case de puxar placa

case 'placa':
    if (!isPremium) return reply('Você não é VIP. Por gentileza, fale com o meu dono: @necrofalante');
    if (q.length < 3) return reply(`Exemplo: /placa NumeroDaPlaca`);
    reply(`Aguarde *${name},* estou procurando os dados do alvo em meu BANCO DE DADOS...`);
    console.log(`${color(`• [CONSULTA] ~>`, 'yellow')} ${color('Consultando a Placa', 'pink')} ${color(`${q}`, 'white')}`);
    try {
        const response = await axios.get(`https://nexasearch.com.br/dados/placa3.php?apikey=7469698659961922868b96a9c4720369&placa=${q}`);
        const data = response.data;

        if (data) {
            const veiculo = data.Veiculo || {};
            const proprietario = data.Proprietário || {};
            const situacao = data.Situacao || {};
            const documentacao = data.Documentacao || {};

            const respostaFormatada = `
- <b>🚘 CONSULTA COMPLETA DA PLACA</b>
\n🚗 <b>PLACA</b>: ${veiculo.Placa || "Dados não encontrados"}
🔧 <b>CHASSI</b>: ${veiculo.Chassi || "Dados não encontrados"}
📄 <b>RENAVAM</b>: ${veiculo.Renavam || "Dados não encontrados"}
🚙 <b>MARCA/MODELO</b>: ${veiculo.MarcaModelo || "Dados não encontrados"}
📆 <b>ANO DE FABRICAÇÃO/MODELO</b>: ${veiculo['AnoFabricação/Modelo'] || "Dados não encontrados"}
✅ <b>SITUAÇÃO</b>: ${situacao.Status || "Dados não encontrados"}
⚠️ <b>IMPEDIMENTOS</b>: ${situacao.Impedimento || "Dados não encontrados"}
👤 <b>PROPRIETÁRIO</b>: ${proprietario.Nome || "Dados não encontrados"}
🆔 <b>CPF</b>: ${proprietario.CPF || "Dados não encontrados"}
🪪 <b>RG/ÓRGÃO EXPEDIDOR</b>: ${proprietario['RG/Órgão Expedidor'] || "Dados não encontrados"}
🏙️ <b>MUNICÍPIO</b>: ${veiculo['PlacaAnterior/Municipio'] || "Dados não encontrados"}
🛡️ <b>SEGURO/CATEGORIA</b>: ${documentacao.SeguroCategoria || "Dados não encontrados"}
📜 <b>ÚLTIMO IPVA PAGO</b>: ${documentacao['ultimoIPVAPago(Integralmente)'] || "Dados não encontrados"}
📫 <b>ENDEREÇO RESIDENCIAL</b>: ${data.EndereçoResidencial?.join(", ") || "Dados não encontrados"}
📮 <b>ENDEREÇO DE CORRESPONDÊNCIA</b>: ${data.EndereçoCorrespondência?.join(", ") || "Dados não encontrados"}
🚨 <b>OCORRÊNCIAS DE ROUBO/FURTO</b>: ${data['PossuiOcorrenciadeRoubo/Furto?'] || "Dados não encontrados"}
🛠️ <b>DADOS DO LEILÃO</b>: ${data.DadosdoLeilao || "Dados não encontrados"}
📊 <b>HISTÓRICO DO PROPRIETÁRIO</b>: ${data.HistoricodoProprietario || "Dados não encontrados"}
`;

            duda.replyWithHTML(respostaFormatada);
        } else {
            duda.reply("⚠️ Nenhuma informação encontrada para a placa informada.");
        }
    } catch (error) {
        duda.reply("❌ Erro ao realizar a consulta. Verifique se a placa está correta.");
        console.error(error);
    }
break;



case 'placa2':
if (!isPremium) return reply('Você não é vip, por gentileza, fale com o meu dono!: @necrofalante') 
try {
if (q.length < 3) return  reply(`Exemple: /placa NumeroDaPlaca`)
 reply(`Aguarde *${name},* estou a procurar os dados do alvo em meu BANCO DE DADOS...`)
 console.log(`${color(`• [CONSULTA] ~>`, 'yellow')} ${color('Consultando o Placa', 'pink')} ${color(`${q}`, 'white')}`)
alizin = await axios.get(`http://8.222.207.34:8080/sky1/nome/${q}`);
reply(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗣𝗟𝗔𝗖𝗔 🕵️
═════════════════

${alizin.data}


*DONO: [@necrofalante]*
═════════════════`)
dbplaca.push(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗣𝗟𝗔𝗖𝗔 🕵️
═════════════════

${alizin.data}


*DONO: [@necrofalante]*
═════════════════`)
fs.writeFileSync('./database/DB PRÓPRIA/nome.json',JSON.stringify(dbplaca, null, 1))
} catch (e) {
reply(`Ola *${name},* Ocorreu Um Erro Nas Minhas Buscas, Reporte Ao Meu PROGRAMADOR.`)
}
break



//case de puxar nome
case 'nome':
case 'nome1':
if (!isPremium) return reply('Você não é vip, por gentileza, fale com o meu dono!: @necrofalante');
try {
    if (q.length < 10) 
        return reply(`⚠️ Nome inválido! Insira pelo menos nome e sobrenome do alvo para buscar.`);

    reply(`Aguarde *${name},* estou a procurar os dados do alvo em meu BANCO DE DADOS...`);
    console.log(`${color('• [CONSULTA] ~>', 'yellow')} ${color('Consultando o Nome', 'pink')} ${color(`${q}`, 'white')}`);

    const response = await axios.get(`http://br1.sixhosting.online:10000/api/consulta?token=alucard2025&type=nomeData&query=${q}`);
    const data = response.data;

    if (data && data.itens && data.itens.length > 0) {
        let resultado = `🕵️ **Consulta por Nome**\n\n`;
        data.itens.forEach((item, index) => {
            const endereco = item.endereco || {};
            resultado += `🔢 **Registro ${index + 1}:**\n` +
                `👤 **Nome:** ${item.nome || '---'}\n` +
                `🧾 **CPF:** ${item.cpf || '---'}\n` +
                `⚥ **Sexo:** ${item.sexo || '---'}\n` +
                `🎂 **Data de Nascimento:** ${item.nascimento || '---'}\n` +
                `👩‍👦 **Nome da Mãe:** ${item.mae || '---'}\n` +
                `👨‍👦 **Nome do Pai:** ${item.pai || '---'}\n` +
                `📊 **Score CSB8:** ${item.score?.CSB8 || '---'}\n` +
                `📊 **Score CSBA:** ${item.score?.CSBA || '---'}\n` +
                `🏠 **Endereço:**\n` +
                `   • Tipo Logradouro: ${endereco.tipo_logradouro || '---'}\n` +
                `   • Logradouro: ${endereco.logradouro || '---'}\n` +
                `   • Número: ${endereco.numero || '---'}\n` +
                `   • Complemento: ${endereco.complemento || '---'}\n` +
                `   • Bairro: ${endereco.bairro || '---'}\n` +
                `   • Cidade: ${endereco.cidade || '---'}\n` +
                `   • UF: ${endereco.uf || '---'}\n` +
                `   • CEP: ${endereco.cep || '---'}\n\n`;
        });

        const path = require('path');
        const dir = path.resolve('./database/DB_PRÓPRIA/');
        const fileName = path.join(dir, 'nome_resultado.txt');

        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }

        fs.writeFileSync(fileName, resultado, 'utf-8');
        console.log(`📂 Arquivo salvo em: ${fileName}`);

        const sentMessage = await duda.telegram.sendDocument(duda.chat.id, {
            source: fileName,
            filename: 'consulta_nome.txt',
        }, {
            caption: "📄 Aqui está o resultado completo da sua consulta por Nome!",
            reply_to_message_id: duda.message.message_id, // Marca a mensagem original
        });

        console.log("📄 Arquivo enviado com sucesso!");

        // Excluir mensagem automaticamente após 30 segundos
        setTimeout(async () => {
            try {
                await duda.telegram.deleteMessage(duda.chat.id, sentMessage.message_id);
                console.log(`📄 Mensagem de consulta excluída automaticamente após 30 segundos.`);
            } catch (e) {
                console.error("Erro ao excluir mensagem automaticamente:", e.message);
            }
        }, 30000); // 30 segundos
    } else {
        const noResultMessage = await reply(`🚫 Nenhuma informação foi encontrada para o nome solicitado. Por favor, verifique os dados e tente novamente.`, {
            reply_to_message_id: duda.message.message_id,
        });

        // Excluir mensagem automaticamente após 30 segundos
        setTimeout(async () => {
            try {
                await duda.telegram.deleteMessage(duda.chat.id, noResultMessage.message_id);
                console.log("🚫 Mensagem de 'nenhum resultado encontrado' excluída automaticamente após 30 segundos.");
            } catch (e) {
                console.error("Erro ao excluir mensagem automaticamente:", e.message);
            }
        }, 30000); // 30 segundos
    }
} catch (e) {
    const errorMessage = await reply(`❌ Ocorreu um erro nas minhas buscas. Por favor, reporte ao meu PROGRAMADOR.`, {
        reply_to_message_id: duda.message.message_id,
    });

    // Excluir mensagem automaticamente após 30 segundos
    setTimeout(async () => {
        try {
            await duda.telegram.deleteMessage(duda.chat.id, errorMessage.message_id);
            console.log("❌ Mensagem de erro excluída automaticamente após 30 segundos.");
        } catch (e) {
            console.error("Erro ao excluir mensagem automaticamente:", e.message);
        }
    }, 30000); // 30 segundos

    console.error('Erro ao realizar consulta por nome:', e.message);
}
break;














case 'nome2':
if (!isPremium) return reply('Você não é vip, por gentileza, fale com o meu dono!: @necrofalante') 
try {
if (q.length < 10) return  reply(`Nome inválido! Insira pelo menos nome e sobrenome do alvo para buscar.`)
  reply(`Aguarde *${name},* estou a procurar os dados do alvo em meu BANCO DE DADOS...`)
  console.log(`${color(`• [CONSULTA] ~>`, 'yellow')} ${color('Consultando o Nome', 'pink')} ${color(`${q}`, 'white')}`)
alizin = await fetchJson(`http://br1.sixhosting.online:10000/api/consulta?token=alucard2025&type=nomeData&query=${q}`);
reply(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗡𝗢𝗠𝗘 🕵️
═════════════════

${alizin.resultado.str}


*DONO: [@necrofalante]*
═════════════════`)
dbnome.push(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗡𝗢𝗠𝗘 🕵️
═════════════════

${alizin.resultado.str}


*DONO: [@necrofalante]*
═════════════════`)
fs.writeFileSync('./database/DB PRÓPRIA/nome.json',JSON.stringify(dbnome, null, 1))
} catch (e) {
reply(`Ola *${name},* Ocorreu Um Erro Nas Minhas Buscas, Reporte Ao Meu PROGRAMADOR.`)
}
break




//case de puxar cpf

case 'chk':
    const commandParts = body.split(' ');
    
    if (commandParts.length < 2) {
reply('Formato incorreto. Use: /chk [lista]');
break;
    }
    
    const cardInfo = commandParts[1];
    const apiUrl = `https://alizin.repl.co/chk.php?lista=${encodeURIComponent(cardInfo)}`;
    
    try {
const response = await fetch(apiUrl);
const result = await response.text();

reply(result);
    } catch {
reply('Algo deu errado chefe');
    }
    break
//

case 'cpf':
if (!isPremium) return reply('Você não é vip, por gentileza, fale com o meu dono!: @necrofalante');
try {
    if (q.length !== 11 || isNaN(q)) 
        return reply(`⚠️ O CPF informado está inválido. Insira um CPF com exatamente 11 dígitos numéricos e verifique se está correto!`);
    
    reply(`Aguarde *${name},* estou a procurar os dados do alvo em meu BANCO DE DADOS...`);
    console.log(`${color('• [CONSULTA] ~>', 'yellow')} ${color('Consultando o CPF', 'pink')} ${color(`${q}`, 'white')}`);
    
    const response = await axios.get(`https://00f9-45-181-73-138.ngrok-free.app/${q}`);
    const data = response.data;

    if (data && data.resultado) {
        const resultado = data.resultado
            .replace(/CNS:/g, "🆔 CNS:\n")
            .replace(/Nome:: Nome Social \/ Apelido:/g, "👤 Nome:\n🔹 Apelido:\n")
            .replace(/Nome da Mãe:: Nome do Pai:/g, "👩‍👦 Nome da Mãe:\n👨‍👦 Nome do Pai:\n")
            .replace(/Sexo:: Raça:/g, "⚥ Sexo:\n🌈 Raça:\n")
            .replace(/Data de Nascimento:: Tipo Sanguíneo:/g, "🎂 Data de Nascimento:\n💉 Tipo Sanguíneo:\n")
            .replace(/Nacionalidade:: País de Nascimento:/g, "🌎 Nacionalidade:\n📍 País de Nascimento:\n")
            .replace(/Data de Entrada no Brasil:/g, "🛬 Data de Entrada no Brasil:\n")
            .replace(/Tipo de Moradia:/g, "🏠 Tipo de Moradia:\n")
            .replace(/Detalhes do Óbito:/g, "⚰️ Detalhes do Óbito:\n")
            .replace(/Data de Óbito:: Num. Documento:/g, "🗓️ Data de Óbito:\n📜 Número do Documento:\n")
            .replace(/Cod. Sistema Origem:: Nome Sistema Origem:/g, "💻 Código do Sistema Origem:\n📂 Nome do Sistema Origem:\n")
            .replace(/Motivo:/g, "📋 Motivo:\n")
            .replace(/Contatos:/g, "📞 Contatos:\n")
            .replace(/Telefone\(s\):/g, "📱 Telefone(s):\n")
            .replace(/Documentos:/g, "📑 Documentos:\n")
            .replace(/CPF:/g, "🧾 CPF:\n");
        
        reply(`- 🕵️ CONSULTA COMPLETA DO CPF\n\n👤 **Dados Pessoais:**\n${resultado}\n\n**Dono:** @necrofalante`);
        dbcpf.push(`- 🕵️ CONSULTA COMPLETA DO CPF\n\n${resultado}\n\nDono: @necrofalante`);
        fs.writeFileSync('./database/DB PRÓPRIA/cpf.json', JSON.stringify(dbcpf, null, 1));
    } else {
        reply("⚠️ Nenhuma informação encontrada para o CPF informado.");
    }
} catch (e) {
    console.error('❌ Erro ao realizar a consulta:', e.message);
    reply("❌ Erro ao realizar a consulta. Verifique se o CPF está correto ou tente novamente mais tarde.");
}
break;










case 'cpf2':
if (!isPremium) return reply('Você não é vip, por gentileza, fale com o meu dono!: @necrofalante') 
try {
if (q.length < 11 || q.length > 11) return reply(`O cpf informado está inválido. Insira um com no máximo de 11 dígitos e verifique-se se está correto!`)
reply(`Aguarde *${name},* estou a procurar os dados do alvo em meu BANCO DE DADOS...`)
console.log(`${color(`• [CONSULTA] ~>`, 'yellow')} ${color('Consultando o Cpf', 'pink')} ${color(`${q}`, 'white')}`)
alizin = await fetchJson(`http://fra2.to.esthosting.com.br:30003/cpf2/${q}`);
reply(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗖𝗣𝗙 🕵️
═════════════════

${alizin.resultado.str}


*DONO: [@necrofalante]*
═════════════════`)
dbcpf.push(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗖𝗣𝗙 🕵️
═════════════════

${alizin.resultado.str}


*DONO: [@necrofalante]*
═════════════════`)
fs.writeFileSync('./database/DB PRÓPRIA/cpf.json',JSON.stringify(dbcpf, null, 1))
} catch (e) {
console.log(e)
}
break

case 'cpf3':
if (!isPremium) return reply('Você não é vip, por gentileza, fale com o meu dono!: @necrofalante') 
try {
if (q.length < 11 || q.length > 11) return reply(`O cpf informado está inválido. Insira um com no máximo de 11 dígitos e verifique-se se está correto!`)
reply(`Aguarde *${name},* estou a procurar os dados do alvo em meu BANCO DE DADOS...`)
console.log(`${color(`• [CONSULTA] ~>`, 'yellow')} ${color('Consultando o Cpf', 'pink')} ${color(`${q}`, 'white')}`)
alizin = await fetchJson(`http://fra2.to.esthosting.com.br:30003/cpf3/${q}`);
reply(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗖𝗣𝗙 🕵️
═════════════════

${alizin.resultado.str}


*DONO: [@necrofalante]*
═════════════════`)
dbcpf.push(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗖𝗣𝗙 🕵️
═════════════════

${alizin.resultado.str}


*DONO: [@necrofalante]*
═════════════════`)
fs.writeFileSync('./database/DB PRÓPRIA/cpf.json',JSON.stringify(dbcpf, null, 1))
} catch (e) {
reply(`Ola *${name},* Ocorreu Um Erro Nas Minhas Buscas, Reporte Ao Meu PROGRAMADOR.`)
}
break

case 'cpf4':
if (!isPremium) return reply('Você não é vip, por gentileza, fale com o meu dono!: @necrofalante') 
try {
if (q.length < 11 || q.length > 11) return reply(`O cpf informado está inválido. Insira um com no máximo de 11 dígitos e verifique-se se está correto!`)
reply(`Aguarde *${name},* estou a procurar os dados do alvo em meu BANCO DE DADOS...`)
console.log(`${color(`• [CONSULTA] ~>`, 'yellow')} ${color('Consultando o Cpf', 'pink')} ${color(`${q}`, 'white')}`)
alizin = await fetchJson(`http://fra2.to.esthosting.com.br:30003/cpf4/${q}`);
reply(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗖𝗣𝗙 🕵️
═════════════════

${alizin.resultado.str}


*DONO: [@necrofalante]*
═════════════════`)
dbcpf.push(`═════════════════
🕵️ 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗖𝗣𝗙 🕵️
═════════════════

${alizin.resultado.str}


*DONO: [@necrofalante]*
═════════════════`)
fs.writeFileSync('./database/DB PRÓPRIA/cpf.json',JSON.stringify(dbcpf, null, 1))
} catch (e) {
console.log(e)
}
break

		}
		
if (body.startsWith('>')) {
if (!isDono) return reply('So meu dono');
try {
return reply(JSON.stringify(eval(body.slice(2)),null,'\t'))
} catch(e) {
reply(`${e}`)
}
}


	} catch (e) {
		console.log(chalk.whiteBright('├'), chalk.cyanBright('[  ERROR  ]'), chalk.redBright(e))
	}
})


bot.launch({
	dropPendingUpdates: true,
})
bot.telegram.getMe().then((getme) => {
	itsPrefix = prefix != '' ? prefix : 'No Prefix'
	console.log(chalk.greenBright(' ╭==================================================='))
	console.log(chalk.greenBright(' │ + Donos    : ' + owner || ''))
	console.log(chalk.greenBright(' │ + Nome do bot : ' + getme.first_name || ''))
	console.log(chalk.greenBright(' │ + Versão  : ' + version || ''))
	console.log(chalk.greenBright(' │ + Hospedagem     : ' + os.hostname() || ''))
	console.log(chalk.greenBright(' │ + Plataforma : ' + os.platform() || ''))
	console.log(chalk.greenBright(' │ + Prefix   : ' + itsPrefix))
	console.log(chalk.greenBright(' ╰==================================================='))
	console.log(chalk.whiteBright('╭─── [ REGISTROS ]'))
})
process.once('SIGINT', () => bot.stop('SIGINT'))
process.once('SIGTERM', () => bot.stop('SIGTERM'))

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`𝜟𝐓𝐔𝜟𝐋𝐈𝐙𝜟𝐂̧𝜟̃𝚯: '${__filename}'`))
	delete require.cache[file]
	require(file)
})

