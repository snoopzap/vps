clear
sleep 2
echo "\n Aguarde, iniciando...."
sleep 3
clear
sleep 2
echo "\n Executando: pkg install git"
sleep 2
clear
sleep 2
pkg install git
clear
sleep 2
echo "\n Executando: pkg upgrade -y"
sleep 2
clear
sleep 2
pkg upgrade -y
clear
sleep 1
echo "\n Executando: pkg update -y"
sleep 2
clear
sleep 2
pkg update -y
clear
sleep 2
echo "\n Executando: pkg install nodejs -y"
sleep 2
clear
sleep 2
pkg install nodejs -y
clear
sleep 3
echo "\n Executando: pkg install nodejs-lts -y"
sleep 2
clear
sleep 2
pkg install nodejs-lts -y
clear
sleep 4
clear
echo "iniciando..."
sleep 5
clear
node index.js